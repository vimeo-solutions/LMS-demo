var RXDConfig = {
    // the entry URL to the content
    contentUrl: "https://vimeo.com/lms/content/237963585/video/1163991005?scoring_algorithm=quiz&completion_threshold=90&passing_score=80&course_title=%E2%9C%A8Turn+viewers+into+participants+with+Vimeo%27s+new+interactive+editor%21+-+LMS+demo&skipping_forward=true&speed=true",

    // value to use as the HTML title for the proxy package
    courseTitle: "✨Turn viewers into participants with Vimeo's new interactive editor! - LMS demo",

    // URL where the RXD files are located and available via http/s
    rxdHostUrl: "https://vimeo.com/assets/rxd",

    // the path to the content API wrapper page, appended to the rxdHostUrl
    // unless it is an absolute http/s URL
    contentApi: "contentAPI.html",

    // URL to fetch pre-launch configuration settings from
    // Leave as an empty string if not using (e.g., "")
    preLaunchConfigurationUrl: ""
};
